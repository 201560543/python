import os
f= open("compare.py", 'r')
g= open("compare_mod.py",'w')
f1= open("pdb_id.txt", 'r')
f2= open("chain.txt", 'r')
pdb = f1.readlines()
ch = f2.readlines()
comp = f.readlines()
l = len(comp)
for i in range(4):
	g.write(comp[i])

for i in range(4):
	trans1 = pdb[i].split()
	trans2 = ch[i].split() 
    	g.write("('"+ str(trans1[0])+"', '"+ str(trans2[0])+"'),"+"\n")
trans3= pdb[4].split()
trans4= ch[4].split()
g.write("('"+ str(trans3[0])+"', '"+ str(trans4[0])+"')"+"\n")
	
for i in range(5,13):
	g.write(comp[i])
g.close()
os.system("mod9.16 compare_mod.py")

#takes input from compare.py and writes into compare_mod.py with additional info (5 pdb ids and corresponding chains) 
