import os
f= open("compare_mod.log", 'r')
comp = f.readlines()
l= len(comp)
s=[]
q=[]
p=[]
for i in range (l):
	s=comp[i].split(" ")
	if (s[0] == "Weighted"):
		for j in range (i+3,i+12,2):
			trans = comp[j].split("@")
                        val = trans[1].split(" ")
			pid = trans[0].split("- ")
			q.append(val[0])	
			p.append(pid[1])
x= q[4].split("\n")
q[4] = x[0]
j=q.index(min(q))  
pdb_id=p[j][:4]
pdb_c=p[j][4:-1]  
f.close()
g=open('align2d.py','r')
aln=g.readlines()
g.close()
h=open('align2d_mod.py','w')
for i in range(3):
	h.write(aln[i])
h.write(aln[3][:23])
h.write(pdb_id)
h.write(aln[3][27:52])

h.write(pdb_c)
h.write(aln[3][53:61])
h.write(pdb_c)
h.write(aln[3][62:66])

h.write(aln[4][:35])
h.write(p[j][:5])
h.write(aln[4][40:55])
h.write(pdb_id)
h.write(aln[4][59:66])
h.write(aln[5])
h.write(aln[6])
h.write(aln[7][:22])
h.write(p[j][:5])
h.write(aln[7][27:58])
h.write(aln[8][:22])
h.write(p[j][:5])
h.write(aln[8][27:58])
h.close()

i=open('app_pdb.txt','w')
i.write(p[j][:5])
i.close()
os.system("mod9.16 align2d_mod.py")
#takes compare_mod.log as input and gives pdb_id of the most appropriate template  
