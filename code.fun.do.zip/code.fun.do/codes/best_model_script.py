from Tkinter import *
from tkMessageBox import *
f=open('model-single_mod.log','r')
g=open('b_model','w')
trans=f.readlines()
arr_final=[]
for i in range(len(trans)):
	arr=trans[i].split()
	if (len(arr)>0):
		if (arr[0]=='Filename'):
			break
for j in [i+2,i+3,i+4,i+5,i+6]:
	arr1=trans[j].split()
	arr_final.append(float(arr1[1]))
min_arr=arr_final.index(min(arr_final))
best="TvLDH.B9999000"+str(min_arr)+".pdb"

g.write(best)
g.close()
h=open('b_model','r')
trans=h.readline()
showinfo('Best Structure', 'Best structure is %s.Please see the output folder' %(trans))
