f=open("my_blast.out",'r')
f_out = open ("my_parse.txt",'w')
array=f.readlines()
n=len(array)
trans=[]
for i in range(n-1):
	trans=array[i].split()
	if (trans[0]=='<Hit>'):
		trans2=array[i+2].split("|")
                f_out.write(trans2[3]+"\t")	
		trans3=trans2[4].split("<")
                f_out.write(trans3[0]+"\t")	
        if (trans[0]=='<Hsp>'):
                trans4=array[i+4].split("<")
		trans5=trans4[1].split(">")
                f_out.write(trans5[1]+"\n")

#takes input from my_blast.out gives output of blast in tabular form in text file - my_parse.txt
