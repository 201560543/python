import urllib2
f= open("pdb_id.txt",'r')
f1= open("evalue.txt",'r')
pdb= f.readlines()
new= f1.readlines()
l= len(new)
for i in range(5):
    e=new[i].split("-")
    if (int(e[1])>20) or (int(e[1])==20):
	trans=pdb[i].split()
	url_1 = 'http://files.rcsb.org/view/'
	url_2 = '.pdb'
	url_final = url_1+trans[0]+url_2
	
	response = urllib2.urlopen(url_final)
        
	with open(trans[0]+'.pdb', 'w') as g:
    		 g.write(response.read())
    else:
         print "\nHomology not possible as e-value is < 20."
         break

#takes pdb_id from pdb_id.txt and opens web site and stores the pdb file of each pdb entry in pdb format


        
