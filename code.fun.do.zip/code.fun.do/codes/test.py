from Bio.Blast import NCBIWWW
fasta_string = open("sequence.fasta").read()



result_handle = NCBIWWW.qblast("blastp", "pdb", fasta_string)

save_file = open('my_blast.out', 'w')
blast_results = result_handle.read()
save_file.write(blast_results)
save_file.close()

#takes input protein sequence and stores blast output in my_blast.out
