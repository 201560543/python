g=open("sequence.fasta",'r')
fasta_string=g.readlines()
f=open("TvLDH.ali",'w')
f.write(">P1;TvLDH\nsequence:TvLDH:::::::0.00: 0.00\n")
a=fasta_string[len(fasta_string) -1].rstrip()
for i in range(1,len(fasta_string)-1):	
	f.write(fasta_string[i])
f.write(a)
f.write('*')
