from Tkinter import *
import os
from tkMessageBox import *

root = Tk()

def save():
    os.system("chmod +x file")
    text = e.get("0.0",END) 
    with open("sequence.fasta", "a") as f:
        f.write(text)
    os.system("./file")

root.title("Automated Homology Modelling Tool" )
w1 = Label(root, text="Please paste the protein sequence in fasta format")
w1.pack()

e = Text()
ScrollBar = Scrollbar(root)
ScrollBar.config(command=e.yview)
e.config(yscrollcommand=ScrollBar.set)
ScrollBar.pack(side=RIGHT, fill=Y)
e.pack(expand=YES, fill=BOTH)

toolbar = Frame(root)

b = Button(toolbar, text="Model", width=9, command=save)
b.pack(side=LEFT, padx=2, pady=2)

b2=Button(root, text="Exit", width=9, command='exit')
b2.pack(side=RIGHT, padx=2, pady=2)

toolbar.pack(side=TOP, fill=X)

mainloop()
