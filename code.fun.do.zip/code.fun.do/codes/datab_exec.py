import sqlite3
conn = sqlite3.connect('anjali.db')
c = conn.cursor()
f=open("my_parse.txt",'r')
f_pdb=open("pdb_id.txt",'w')
f_chain=open("chain.txt",'w')
f_evalue=open("evalue.txt",'w')

array=f.readlines()
trans=[]
list_row=[]
c.execute('''CREATE TABLE Blast_table
             (PDB_ID, Chain, E_value)''')
for i in range(len(array)):
	trans=array[i].split()
	c.execute("INSERT INTO Blast_table VALUES (?,?,?)",trans)

conn.commit()

for row in c.execute('SELECT * FROM Blast_table'):
	list_row=str(row)
        trans=list_row.split('\'')
	f_pdb.write(trans[1]+"\n")
	f_chain.write(trans[3]+"\n")
	f_evalue.write(trans[5]+"\n")

#takes input from my_parse.txt(3 columns - pdb_id,chain,e-value), 
#creates database with table having 3 columns. From the table, 
#takes contents column wise and stores it in in 3 different txt files(pdb_id.txt, chain.txt, evalue.txt).
