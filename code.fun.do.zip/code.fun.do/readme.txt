An automated GUI based tool for Homology Modelling


Steps to follow: 
1. Go to the folder 'codes' and type 'python gui.py'.
2. Enter the protein sequence in text box (fasta format) - sample sequence is given in sequence.fasta.
3. Press the button 'Model'.
4. After some time, the name of the best modelled protein structure will appear on a message box and the output file of the same will be generated in the 'output' folder inside 'codes' folder.


