import MySQLdb as db
con = db.connect("localhost","root","vulcan2")
cur = con.cursor()
cur.execute("CREATE DATABASE pairwise")

con.close()
