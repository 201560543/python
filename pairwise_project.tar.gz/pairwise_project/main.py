import sys, string, os
import alignment
from alignment import *
import MySQLdb
# Command-line arguments
f = open(sys.argv[1],'rU')
header1 = f.readline()
header1 = header1.rstrip(os.linesep)
seq1=''
for line in f:
  line = line.rstrip('\n')
  if(line[0] == '>'):
    header1 = header1[1:]
    header1 = line
    seq1 = ''
  else:
    seq1 += line

f = open(sys.argv[2],'rU')
header2 = f.readline()
header2 = header2.rstrip(os.linesep)
seq2=''
for line in f:
  line = line.rstrip('\n')
  if(line[0] == '>'):
    header2 = header2[1:]
    header2 = line
    seq2 = ''
  else:
    seq2 += line

print "Choose a method to execute for alignment (local or global)"
x=raw_input()

if x == 'global':
    alignment.needle(seq1, seq2)
elif x == 'local':
    alignment.water(seq1, seq2)
else:
    print "Please choose a proper method to execute. \n"
print "___________________________________________________________\n"
print "\nThe VALUES in database pairwise are: \n"

db = MySQLdb.connect("localhost","root","vulcan2","pairwise" )
# prepare a cursor object using cursor() method
cursor = db.cursor()
# Drop table if it already exist using execute() method.
cursor.execute("DROP TABLE IF EXISTS ALIGNMENT")
# Create table as per requirement
sql = "CREATE TABLE ALIGNMENT (SEQ1ID VARCHAR(100) ,SEQ2ID VARCHAR(100) ,ALGORITHM VARCHAR(20) ,MATCH_SCORE INT , MISMATCH INT ,GAP_PENALTY INT , SCORE float NOT NULL,  IDENTITY float)"

cursor.execute(sql)

cursor.execute('insert into ALIGNMENT(SEQ1ID,SEQ2ID,ALGORITHM,MATCH_SCORE,MISMATCH,GAP_PENALTY,SCORE, \
       IDENTITY)values("%s","%s","%s","%d","%d","%d","%f","%f")' % \
             (header1,header2,x,alignment.match_award,alignment.mismatch_penalty,alignment.gap_penalty,alignment.score,alignment.identity))
db.commit()
cursor.execute("SELECT * FROM ALIGNMENT")


data= cursor.fetchall()
print data
print "\n"
db.close()
